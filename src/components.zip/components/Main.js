import Navbar from "./Navbar";
import { Route, Routes } from 'react-router-dom';
import Product from "./Product";
import Home from "./Home";
import Sidebar from "./Sidebar";





const Main = () => {
    return ( 
        <>
        <Navbar/>

        <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path='/products' element={<Product/>}></Route>
            {/* <Route path="/adminpanel" element={<Sidebar/>}></Route> */}
        </Routes>
        </>
     );
}
 
export default Main;